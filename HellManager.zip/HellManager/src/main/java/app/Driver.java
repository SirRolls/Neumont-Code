package app;

import programController.Manager;

public class Driver {

	public static void main(String[] args) {

		Manager.initiateHM();
		
	}

}
