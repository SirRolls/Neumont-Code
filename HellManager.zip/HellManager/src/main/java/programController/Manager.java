package programController;

import gameControllers.Heaven;
import gameControllers.Hell;

public class Manager {
	
	private boolean isMultiplayer;
	private Hell singPlayerHell;
	private Hell multiPlayerHell;
	private Heaven multiPlayerHeaven;
	
	public static void initiateHM() {
		
	}
	
	private static void multiplayerSelection() {
		
	}
	
	private static void singlePlayer() {
		
	}
	
	private static void multiPlayer() {
		
	}
	
	private static Hell createHell() {
		
		return new Hell();
	}

}
