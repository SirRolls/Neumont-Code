package enums;

public enum DifficultyType {

	EASY,
	MEDIUM,
	HARD
	
}
